package org.cap.demo;

public class Student {
	private int stuId;
	private String studName;
	public int getStuId() {
		return stuId;
	}
	public void setStuId(int stuId) {
		this.stuId = stuId;
	}
	public String getStudName() {
		return studName;
	}
	public void setStudName(String studName) {
		this.studName = studName;
	}
	@Override
	public String toString() {
		return "Student [stuId=" + stuId + ", studName=" + studName + "]";
	}
	public Student() {
		
	}
	

}
