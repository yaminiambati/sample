package org.cap.demo;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	//ew AnnotationConfigApplicationContext(JavaConfiguration.class);
		AbstractApplicationContext context = new AnnotationConfigApplicationContext(JavaConfig.class);
		Employee employee = context.getBean(Employee.class);
		System.out.println(employee);
		Student student = context.getBean(Student.class);
		System.out.println(student);
	}
	

}
