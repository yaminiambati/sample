package org.cap.demo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
@Import({MyConfig.class})
@Configuration
public class JavaConfig {
	@Bean
	public Employee getEmpBean() {
		Employee emp = new Employee();
		emp.setEmployeeId(1001);
		emp.setEmployeeName("Jack");
		emp.setSalary(10000);
		emp.setAge(23);
		emp.setAddress(getAddress());
		
		return emp;
	}
	
	@Bean
	public  Address getAddress() {
		Address add = new Address();
		add.setDoorNo("1001");
		add.setCity("Hyderabad");
		add.setStname("Kphb");
		
		return add;
	}
	

}
