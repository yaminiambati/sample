package com.capgemini.PromoRest.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Discount {
	@Id
	private int discountId;
	private int productId;
	private String promoName;
	private double promoAmount;
	private int discountpercent;
	private Date issueDate;
	private Date expiryDate;
	
	public Discount(String promoName) {
		super();
		this.promoName = promoName;
	}
	public int getDiscountId() {
		return discountId;
	}
	public void setDiscountId(int discountId) {
		this.discountId = discountId;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}

	public double getPromoAmount() {
		return promoAmount;
	}
	public void setPromoAmount(double promoAmount) {
		this.promoAmount = promoAmount;
	}
	public int getDiscountpercent() {
		return discountpercent;
	}
	public void setDiscountpercent(int discountpercent) {
		this.discountpercent = discountpercent;
	}
	public Date getIssueDate() {
		return issueDate;
	}
	public void setIssueDate(Date issueDate) {
		this.issueDate = issueDate;
	}
	public Date getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}
	@Override
	public String toString() {
		return "Discount [discountId=" + discountId + ", productId=" + productId + ", promoName=" + promoName
				+ ", promoAmount=" + promoAmount + ", discountpercent=" + discountpercent + ", issueDate=" + issueDate
				+ ", expiryDate=" + expiryDate + "]";
	}
	
	
	public Discount()
	{
		
	}
	

}
