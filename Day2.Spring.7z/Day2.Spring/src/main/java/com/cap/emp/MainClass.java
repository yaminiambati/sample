package com.cap.emp;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		AbstractApplicationContext context= new ClassPathXmlApplicationContext("demobeans.xml");
		Employee emp=(Employee)context.getBean("employee1");
		System.out.println(emp);
		context.registerShutdownHook();
	}

}
