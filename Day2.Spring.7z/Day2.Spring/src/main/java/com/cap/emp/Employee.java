package com.cap.emp;

import javax.annotation.PostConstruct;

import org.cap.demo.Address;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Required;

public class Employee {
private int employeeId;
private String employeeName;
private double salary;
private int age;
private Address address;

public void init_method()
{
	System.out.println("init method initiated");
}

public void destroy_method() {
	System.out.println("destroy method initiated");
	
}
public int getEmployeeId() {
	return employeeId;
}

public void setEmployeeId(int employeeId) {
	this.employeeId = employeeId;
}
public String getEmployeeName() {
	return employeeName;
}
public void setEmployeeName(String employeeName) {
	this.employeeName = employeeName;
}
public double getSalary() {
	return salary;
}
public void setSalary(double salary) {
	this.salary = salary;
}
public int getAge() {
	return age;
}

public void setAge(int age) {
	this.age = age;
}

public Address getAddress() {
	return address;
}
@Autowired
@Qualifier("empaddress1")
public void setAddress(Address address) {
	this.address = address;
}

public Employee() {
	System.out.println("default constructor");
}
@Autowired
public Employee(int employeeId, String employeeName, double salary, int age, Address address) {
	super();
	this.employeeId = employeeId;
	this.employeeName = employeeName;
	this.salary = salary;
	this.age = age;
	this.address = address;
}
@Override
public String toString() {
	return "Employee Id : "+employeeId+"\nEmployee Name : " + employeeName +"\nSalary : " + salary + "\nAge : " + age+ "\nAddress: " +address;
}
}
