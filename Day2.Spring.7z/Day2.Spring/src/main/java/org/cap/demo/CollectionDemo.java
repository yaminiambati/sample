package org.cap.demo;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class CollectionDemo {
private List<String> name;
private List<Address> address;
private Set<Address> address1;
private Set<String> fruits;
private Map<Integer,String> map;
private Properties myprops; 

public Set<Address> getAddress1() {
	return address1;
}
public void setAddress1(Set<Address> address1) {
	this.address1 = address1;
}
public Properties getMyprops() {
	return myprops;
}
public void setMyprops(Properties myprops) {
	this.myprops = myprops;
}
public Set<String> getFruits() {
	return fruits;
}
public void setFruits(Set<String> fruits) {
	this.fruits = fruits;
}
public Map<Integer, String> getMap() {
	return map;
}
public void setMap(Map<Integer, String> map) {
	this.map = map;
}
public List<String> getName() {
	return name;
}
public void setName(List<String> name) {
	this.name = name;
}
public List<Address> getAddress() {
	return address;
}
public void setAddress(List<Address> address) {
	this.address = address;
}



}
