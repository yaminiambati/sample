package org.cap.demo;

public class Address {
	private String doorno;
	private String streetname;
	private String city;
	public String getDoorno() {
		return doorno;
	}
	public void setDoorno(String doorno) {
		this.doorno = doorno;
	}
	public String getStreetname() {
		return streetname;
	}
	public void setStreetname(String streetname) {
		this.streetname = streetname;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	@Override
	public String toString() {
		return " doorno=" + doorno + ", streetname=" + streetname + ", city=" + city ;
	}
	public Address() {
		
	}
	
}
