package org.cap.demo;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AbstractApplicationContext context= new ClassPathXmlApplicationContext("mybeans.xml");
		CollectionDemo collection=(CollectionDemo)context.getBean("collectionlist");
		System.out.println(collection.getName());
		System.out.println(collection.getAddress());
		System.out.println(collection.getFruits());
		System.out.println(collection.getMap());
		System.out.println(collection.getMyprops());
		System.out.println(collection.getAddress1());
	}

}
